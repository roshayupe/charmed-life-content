# Charmed Life mapped translation bundle v5

Embedded source EPUB metadata:

- Book Title: Charmed Life
- Series: Christomanci
- Publisher: Harper Collins

The series value is stored in:

`<meta name="calibre:series" content="Christomanci"/>`

Only `content.opf` and the related source/map/manifest identity hashes changed.
The English chapter text, Russian EPUB, paragraph mappings, and sentence groups
remain unchanged.
