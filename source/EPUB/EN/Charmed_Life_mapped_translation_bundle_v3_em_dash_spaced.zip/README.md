# Charmed Life mapped translation bundle v3

Atomic source/target/mapping package for the `mapped_bundle` generation scenario.

Source normalization applied:
- em dashes attached to word characters were changed to token-safe spacing: `word—word` → `word — word`;
- 221 replacements in the packaged English EPUB;
- 217 matching replacements in alignment-map source text;
- sentence IDs and sentence-group mappings are unchanged;
- sentence offsets and paragraph hashes were recalculated.

Contents:
- `source/book.epub` — normalized English source EPUB
- `target/book.ru.epub` — independent Russian translation EPUB
- `mapping/alignment-map.v2.json` — refined locked sentence groups with updated source text/hashes
- `reports/refined-mapping-report.json` — updated structural report
- `reports/em-dash-spacing-validation.json` — package validation details

SentAlign is intentionally bypassed.
