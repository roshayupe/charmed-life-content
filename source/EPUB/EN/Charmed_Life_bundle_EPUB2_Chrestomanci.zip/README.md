# Charmed Life mapped translation bundle v5

Embedded source EPUB metadata:

- Book Title: Charmed Life
- Series: Chrestomanci
- Publisher: Harper Collins

The series value is stored in:

`<meta name="calibre:series" content="Chrestomanci"/>`

Only `content.opf` and the related source/map/manifest identity hashes changed.
The English chapter text, Russian EPUB, paragraph mappings, and sentence groups
remain unchanged.


## Cover replacement

The source and target EPUB covers were replaced with the supplied `Charmed Life Harper Colins cover.webp` artwork. The image is stored as `cover.jpeg` for EPUB 2/3 compatibility.
