# Charmed Life mapped translation bundle v6 — EPUB 3

Both embedded books are EPUB 3 resources.

## EPUB 3 features

- OPF package version: 3.0
- Required `dcterms:modified`: 2026-07-21T12:00:00Z
- EPUB 3 `nav.xhtml`
- Standard series metadata:
  - `belongs-to-collection`: Chrestomanci
  - `collection-type`: series
  - `group-position`: 1
- Legacy Calibre series metadata retained for compatibility
- NCX retained as a fallback for older reading systems

## Bundle contents

- `manifest.json`
- `source/book.epub`
- `target/book.ru.epub`
- `mapping/alignment-map.v2.json`
- `reports/refined-mapping-report.json`
- `reports/epub3-conversion-report.json`

The source and target chapter text, paragraph IDs, sentence offsets, and all
5488 locked sentence groups are unchanged.
Only EPUB package/navigation metadata and the related identity hashes changed.


## Cover replacement

The source and target EPUB covers were replaced with the supplied `Charmed Life Harper Colins cover.webp` artwork. The image is stored as `cover.jpeg` for EPUB 2/3 compatibility.


## Chapter opener normalization

Decorative drop-cap splits at the beginning of all 16 English chapters were normalized, for example `C AT` → `CAT`, `T HE` → `THE`, and `G WENDOLEN` → `GWENDOLEN`.
