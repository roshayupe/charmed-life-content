# Charmed Life mapped translation bundle v2

Atomic source/target/mapping package for the `mapped_bundle` generation scenario.

Contents:
- `source/book.epub` — exact English source EPUB
- `target/book.ru.epub` — independent Russian translation EPUB
- `mapping/alignment-map.v2.json` — refined locked sentence groups
- `reports/refined-mapping-report.json` — structural validation report

SentAlign is intentionally bypassed. Sentence groups are explicit, monotonic, and cover every source and target sentence exactly once.
